<?php

class Pelanggan extends CI_Controller{
    function __construct() {
        parent::__construct();
       $this->load->model('m_pelanggan');
    }
    
    function index(){
        $config=array();
        $config['site_url'] = site_url('pelanggan'); //merupakan alamat url menuju class/fundtion pada controler yang berisi pagination
        $data['data'] = $this->m_pelanggan->tampil($config);
		$this->load->view('v_pelanggan', $data);
    }
	
	function tambah(){
		$data['data'] = $this->m_pelanggan->pelanggan();
		$this->load->view('tambah_pelanggan', $data);
	}
	
	function proses_tambah(){
		$data['id_pelanggan'] = $this->input->post('id_pelanggan');
		$data['nama_pelanggan'] = $this->input->post('nama_pelanggan');
		
		$this->m_pelanggan->tambah($data);
		redirect(base_url('/pelanggan'));
	}
	
	function edit(){
		$id_pelanggan = $this->input->get('id_pelanggan');
		$data['entry'] = $this->m_pelanggan->get($id_pelanggan);
		if(!isset($data['entry'][0]) || $data['entry'][0] == ""){
			redirect(base_url('/pelanggan')."");
		}else {
			$data['entry'] = $data['entry'][0];
			$this->load->view('edit_pelanggan', $data);
		}
	}
	
	function proses_edit(){
		$data['id_pelanggan'] = $this->input->get('id_pelanggan');
		$data['nama_pelanggan'] = $this->input->post('nama_pelanggan');
		
		$this->m_pelanggan->update($data);
		redirect(base_url('/pelanggan')."");
	}
	
	 function proses_hapus(){
        $data['id_pelanggan'] = $this->input->get('id_pelanggan');
        if($data['id_pelanggan'] !="") {
            $this->m_pelanggan->hapus($data);
        }
        redirect(base_url('/pelanggan')."");
    }
   
	
}

