<?php

class Barang extends CI_Controller{
    function __construct() {
        parent::__construct();
       $this->load->model('m_barang');
    }
    
    function index(){
        $config=array();
        $config['site_url'] = site_url('barang');
        $data['data'] = $this->m_barang->tampil($config);
		$this->load->view('v_barang', $data);
    }
	
	function tambah(){
		$data['data'] = $this->m_barang->jenis_barang();
		$this->load->view('tambah_barang', $data);
	}
	
	function proses_tambah(){
		$data['id_barang'] = $this->input->post('id_barang');
		$data['nama_barang'] = $this->input->post('nama_barang');
		$data['harga_barang'] = $this->input->post('harga_barang');
		$data['id_jenis'] = $this->input->post('id_jenis');
		
		$this->m_barang->tambah($data);
		redirect(base_url('/barang'));
	}
	
	function edit(){
		$data['f'] = $this->m_barang->jenis_barang();
		$id_barang = $this->input->get('id_barang');
		$data['entry'] = $this->m_barang->get($id_barang);
		if(!isset($data['entry'][0]) || $data['entry'][0] == ""){
			redirect(base_url('/barang')."");
		}else {
			$data['entry'] = $data['entry'][0];
			$this->load->view('edit_barang', $data);
		}
	}
	
	function proses_edit(){
		$data['id_barang'] = $this->input->get('id_barang');
		$data['nama_barang'] = $this->input->post('nama_barang');
		$data['id_jenis'] = $this->input->post('id_jenis');
		
		$this->m_barang->update($data);
		redirect(base_url('/barang')."");
	}
	
	 function proses_hapus(){
        $data['id_barang'] = $this->input->get('id_barang');
        if($data['id_barang'] !="") {
            $this->m_barang->hapus($data);
        }
        redirect(base_url('/barang')."");
    }
   
	
}

