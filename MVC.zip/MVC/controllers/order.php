<?php

class Order extends CI_Controller{
    function __construct() {
        parent::__construct();
       $this->load->model('m_order');
    }
    
    function index(){
        $config=array();
        $config['site_url'] = site_url('order');
        $data['data'] = $this->m_order->tampil($config);
		$this->load->view('v_order', $data);
    }
	
	function tambah(){
		$data['d'] = $this->m_order->detail_order();
		$data['b'] = $this->m_order->barang();
		$data['p'] = $this->m_order->pelanggan();
		$this->load->view('tambah_order', $data);
	}
	
	function proses_tambah(){
		$data['id_order'] = $this->input->post('id_order');
		$data['id_barang'] = $this->input->post('id_barang');
		$data['tgl_order'] = $this->input->post('tgl_order');
		$data['id_pelanggan'] = $this->input->post('id_pelanggan');
		
		$this->m_order->tambah($data);
		redirect(base_url('/order'));
	}
	
	function edit(){
		$data['f'] = $this->m_barang->jenis_barang();
		$id_barang = $this->input->get('id_barang');
		$data['entry'] = $this->m_barang->get($id_barang);
		if(!isset($data['entry'][0]) || $data['entry'][0] == ""){
			redirect(base_url('/barang')."");
		}else {
			$data['entry'] = $data['entry'][0];
			$this->load->view('edit_barang', $data);
		}
	}
	
	function proses_edit(){
		$data['id_barang'] = $this->input->get('id_barang');
		$data['nama_barang'] = $this->input->post('nama_barang');
		$data['id_jenis'] = $this->input->post('id_jenis');
		
		$this->m_barang->update($data);
		redirect(base_url('/barang')."");
	}
	
	 function proses_hapus(){
        $data['id_barang'] = $this->input->get('id_barang');
        if($data['id_barang'] !="") {
            $this->m_barang->hapus($data);
        }
        redirect(base_url('/barang')."");
    }
   
	
}

