<?php

class Jenis_barang extends CI_Controller{
    function __construct() {
        parent::__construct();
       $this->load->model('m_jenis_barang');
	   
	   //cek login
		
    }
    
    function index(){
        $config=array();
        $config['site_url'] = site_url('jenis_barang'); //merupakan alamat url menuju class/fundtion pada controler yang berisi pagination
        $data['data'] = $this->m_jenis_barang->tampil($config);		
		$this->load->view('header');
        $this->load->view('main_navigation');
        $this->load->view('v_jenis_barang', $data);      
        $this->load->view('footer');
    }
	
	function tambah(){
		$data['data'] = $this->m_jenis_barang->jenis_barang();
		$this->load->view('tambah_jenis_barang', $data);
	}
	
	function proses_tambah(){
		$data['id_jenis'] = $this->input->post('id_jenis');
		$data['jenis_barang'] = $this->input->post('jenis_barang');
		
		$this->m_jenis_barang->tambah($data);
		redirect(base_url('/jenis_barang'));
	}
	
	function edit(){
		$id_jenis = $this->input->get('id_jenis');
		$data['entry'] = $this->m_jenis_barang->get($id_jenis);
		if(!isset($data['entry'][0]) || $data['entry'][0] == ""){
			redirect(base_url('/jenis_barang')."");
		}else {
			$data['entry'] = $data['entry'][0];
			$this->load->view('edit_jenis_barang', $data);
		}
	}
	
	function proses_edit(){
		$data['id_jenis'] = $this->input->get('id_jenis');
		$data['jenis_barang'] = $this->input->post('jenis_barang');
		
		$this->m_jenis_barang->update($data);
		redirect(base_url('/jenis_barang')."");
	}
	
	 function proses_hapus(){
        $data['id_jenis'] = $this->input->get('id_jenis');
        if($data['id_jenis'] !="") {
            $this->m_jenis_barang->hapus($data);
        }
        redirect(base_url('/jenis_barang')."");
    }
   
	
}

