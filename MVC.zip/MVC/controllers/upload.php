<?php 

class Upload extends CI_Controller {
    function __construct() {
        parent::__construct();
        
        // $this->load->model('m_upload');

       
    }

    function index(){

    	$this->load->view('header');
        $this->load->view('main_navigation');
        $this->load->view('v_upload');      
        $this->load->view('footer');
    }
    
    
}