<?php

class Detail_order extends CI_Controller{
    function __construct() {
        parent::__construct();
        $this->load->model('m_detail_order');
    }
	
	function index(){
		$config = array();
		$config['site_url'] = site_url('Detail_order');
		$data['data'] = $this->m_detail_order->tampil($config);
		$this->load->view('v_detail_order', $data);
	}
	
	function tambah(){
		$data['data'] = $this->m_detail_order->detail_order();
		$this->load->view('tambah_detail_order', $data);
	}
	
	function proses_tambah(){
		$data['id_order'] = $this->input->post('id_order');
		$data['jumlah_barang'] = $this->input->post('jumlah_barang');
		$data['harga'] = $this->input->post('harga');
		
		$this->m_detail_order->tambah($data);
		redirect(base_url('/detail_order'));
	}
	
	function edit(){
		$id_order = $this->input->get('id_order');
		$data['entry'] = $this->m_detail_order->get($id_order);
		if(!isset($data['entry'][0]) || $data['entry'][0] == ""){
			redirect(base_url('/detail_order')."");
		}else {
			$data['entry'] = $data['entry'][0];
			$this->load->view('edit_detail_order', $data);
		}
	}
	
	function proses_edit(){
		$data['id_order'] = $this->input->get('id_order');
		$data['jumlah_barang'] = $this->input->post('jumlah_barang');
		$data['harga'] = $this->input->post('harga');
		
		$this->m_detail_order->update($data);
		redirect(base_url('/detail_order')."");
	}
	
	function proses_hapus(){
        $data['id_order'] = $this->input->get('id_order');
        if($data['id_order'] !="") {
            $this->m_detail_order->hapus($data);
        }
        redirect(base_url('/detail_order')."");
    }
	
}




