<?php

class M_barang extends CI_Model{
    function __construct() {
        parent::__construct();
    }
	
	function tambah($data){		
		$this->db->insert('barang', $data);
	}
	
	function jenis_barang(){
        $query = $this->db->get('jenis_barang');
        if($query->num_rows() > 0) {
            foreach($query->result () as $row){
                $data[] = $row;
            }
            return $data;
        }
        return false;
    }
	
	function tampil(){
        $this->db->select('*');
        $this->db->from('barang b');
		$this->db->join('jenis_barang j', 'b.id_jenis=j.id_jenis', 'left');
		
        $query = $this->db->get();
        if($query->num_rows() > 0){
            foreach ($query->result () as $row){
                $data[] = $row;
            }
            return $data;
        }
        return false;
    }
	
	function hapus($data){
        $this->db->delete('barang', array('id_barang'=>$data['id_barang']));
    }
    
	function get($id_barang){
		$this->db->where('id_barang', $id_barang);
		$query = $this->db->get('barang', 1);
		return $query->result();
	}
    
	function update($data){
		$this->db->update('barang', $data, array('id_barang'=>$data['id_barang']));
	}
	
}


