<?php

class M_jenis_barang extends CI_Model{
    function __construct() {
        parent::__construct();
    }
	
	function tambah($data){		
		$this->db->insert('jenis_barang', $data);
	}
	
	function jenis_barang(){
        $query = $this->db->get('jenis_barang');
        if($query->num_rows() > 0) {
            foreach($query->result () as $row){
                $data[] = $row;
            }
            return $data;
        }
        return false;
    }
	
	function tampil(){
        
        $query = $this->db->get('jenis_barang');
        if($query->num_rows() > 0){
            foreach ($query->result () as $row){
                $data[] = $row;
            }
            return $data;
        }
        return false;
    }
	
	function hapus($data){
        $this->db->delete('jenis_barang', array('id_jenis'=>$data['id_jenis']));
    }
    
	function get($id_jenis){
		$this->db->where('id_jenis', $id_jenis);
		$query = $this->db->get('jenis_barang', 1);
		return $query->result();
	}
    
	function update($data){
		$this->db->update('jenis_barang', $data, array('id_jenis'=>$data['id_jenis']));
	}
	
}


