<?php
 class M_detail_order extends CI_Model{
     function __construct() {
         parent::__construct();
     }
	 
	 function tambah($data){
		$this->db->insert('detail_order', $data);
	}
	 
	

	function tampil(){
		$query = $this->db->get('detail_order');
		if($query->num_rows() > 0){
			foreach ($query->result () as $row){
				$data[] = $row;
			}
			return $data;
		}
		return false;
	}
	
	
	
	function detail_order(){
		$query = $this->db->get('detail_order');
		if($query->num_rows() > 0) {
			foreach ($query->result () as $row) {
				$data[] = $row;
			}
			return $data;
		}
		return false;
	}
	
	function get($id_order){
		$this->db->where('id_order', $id_order);
		$query = $this->db->get('detail_order', 1);
		return $query->result();
	}
	
	function update($data){
		$this->db->update('detail_order', $data, array('id_order'=>$data['id_order']));
	}
	
	function hapus($data){
        $this->db->delete('detail_order', array('id_order'=>$data['id_order']));
    }
    
 }


