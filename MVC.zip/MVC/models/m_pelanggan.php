<?php

class M_pelanggan extends CI_Model{
    function __construct() {
        parent::__construct();
    }
	
	function tambah($data){		
		$this->db->insert('pelanggan', $data);
	}
	
	function pelanggan(){
        $query = $this->db->get('pelanggan');
        if($query->num_rows() > 0) {
            foreach($query->result () as $row){
                $data[] = $row;
            }
            return $data;
        }
        return false;
    }
	
	function tampil(){
        
        $query = $this->db->get('pelanggan');
        if($query->num_rows() > 0){
            foreach ($query->result () as $row){
                $data[] = $row;
            }
            return $data;
        }
        return false;
    }
	
	function hapus($data){
        $this->db->delete('pelanggan', array('id_pelanggan'=>$data['id_pelanggan']));
    }
    
	function get($id_pelanggan){
		$this->db->where('id_pelanggan', $id_pelanggan);
		$query = $this->db->get('pelanggan', 1);
		return $query->result();
	}
    
	function update($data){
		$this->db->update('pelanggan', $data, array('id_pelanggan'=>$data['id_pelanggan']));
	}
	
}


