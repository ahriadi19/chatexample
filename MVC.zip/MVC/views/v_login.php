<!DOCTYPE html>
<html>
<head>
<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<meta charset="UTF-8">

<title>Form Login</title>
<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/bootstrap/css/login.css">
</head>

<body>

<div class="logo"></div>
<div class="login-block">
    <h1>Login Admin</h1>
    
    <form class="login-form" action="<?php echo base_url('login/aksi_login'); ?>" method="post">
        <input type="text" value="" placeholder="Username" id="username" name="username" required />
        <input type="password" value="" placeholder="Password" id="password" name="password" required />
        <button type="submit" class="btn btn-danger">Submit</button>
        <br><br><button type="reset" class="btn btn-info" value="Login" title="kembali">Reset</button>
    </form>
    
</div>
</body>

</html>