<?php

class m_upload extends CI_Model {
    function __construct() {
        parent::__construct();
    }
}





