
  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1 id="logo">Sistem Informasi <span>Barang</span></h1>	  
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Jenis Barang</h3>

          <div class="pull-right">
            <p id="tanggal"><?php echo date("d M Y"); ?></p>
			<!--<a href="<?php // echo base_url('login/logout'); ?>" class=""><h3> Log Out</h3></a>-->
        
        
      
            
          </div>
        </div>
        <div class="box-body">
          <div class="">
           <?php echo ""; ?>
            <?php echo anchor('jenis_barang/tambah', '<button class="icon-pencil">Tambah jenis Barang</button>'); ?>
            <?php echo "<br><br>"; ?>
              <!--       search form -->
<!--              <form action="fakultas/search'" method="get" class="sidebar-form">
                <div class="input-group">
                    <input type="text" name="name" class="form-control" placeholder="Search...">
                    <span class="input-group-btn">
                        <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                        </button>
                    </span>
                </div>
              </form>-->
      <!-- /.search form -->

<!--
      <div>
            <?php echo form_open('fakultas/search' ); ?>
            <input type="text" name="search">
            <input type="submit" value="SEARCH">
            <?php echo form_close(); ?>
        </div>-->
        <div class="">
            <div id="header">
                
                
            </div>
            <hr>
            
            
            <table border="1px" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Id Jenis</th>
                        <th>Jenis barang</th>
                        <th>Pilihan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if($data) {
                        foreach ($data as $d)  {
                    
                    ?>
                    <tr>
                        <th><?php echo $d->id_jenis; ?></th>
                        <th><?php echo $d->jenis_barang; ?></th>
                        
                        <th>
                            <?php echo anchor('jenis_barang/edit?id_jenis='.$d->id_jenis, '<button class="btn btn-success">Edit</button>'); ?>
                            <?php echo anchor('jenis_barang/proses_hapus?id_jenis='.$d->id_jenis, '<button class="btn btn-primary">Hapus</button>'); ?>
                        </th>
                    </tr>
                    <?php 
                        }
                    }
                    ?>
                </tbody>
                
            </table>
            <?php // echo $link ?> <!--pemberian untuk nomor pagination-->
        </div>
        </div>
		  
		  
        </div>
